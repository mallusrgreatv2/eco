module.exports = {
  name: "wiki",
  code: `
  $addReactions[✔️;❌]
  $color[RANDOM]
  $title[New Wiki!]
  $description[$message[]]
  $useChannel[762620673188560897]
  $onlyIf[$message[]!=;Please suggest a message!]
  `
}