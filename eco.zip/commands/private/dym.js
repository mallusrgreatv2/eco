module.exports = {
  name: "dym",
  code: `
  
  `
}