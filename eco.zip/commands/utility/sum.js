module.exports = {
  name: "sum",
  code: `
  $title[Sum]
  $description[]
  $addField[Question;$message[1] + $message[2]]
  $addField[Answer;$sum[$message[1];$message[2]]]
  $onlyIf[$message[2]!=;Please give me 2nd arg!]
  $onlyIf[$message[1]!=;Please give me 1st arg!]
`
}