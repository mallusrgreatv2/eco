module.exports = {
  name: "verify",
  code: `
  $dm
  $title[Code]
  $description[<@$authorID>, here is your verification code: $randomString[8]]
  $setUserVar[verifycode;$randomString[8]]
  $onlyIf[$getServerVar[verify]==on;Verification for this server is not on!]
  
  `
}