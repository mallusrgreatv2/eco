module.exports = {
  name: "serverinfo",
 aliases: ["server", "srv", "infoserver", "server-info", "info-server", "guild", "guildinfo"],
 code: `$color[00ff00]
$title[Server Info For $serverName[$guildID]]
$thumbnail[$serverIcon]
$description[
$addField[Role Count;$roleCount]
$addField[Server Region;$region]
$addField[Category Count;$categoryCount]
$addField[Channel Count;$channelCount]
$addField[Bot Count;$membersCount[bot]]
$addField[Human Count;$membersCount[human]]
$addField[Current Server Owner;$username[$ownerID]]
$addField[Current Server Owner ID; $ownerID]
$addField[Server ID;$guildID]
$addField[Verification Level;$serverVerificationLvl]
$addField[Server Name;$serverName[$guildID]]
 `
}
