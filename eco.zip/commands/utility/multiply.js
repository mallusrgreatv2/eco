module.exports = {
  name: "multiply",
  code: `
  $title[Multiply]
  $description[]
  $addField[Answer:;$sum[$message[1];$message[2]]]
  $addField[Question:;$message[1] X $message[2]]
  $addTimestamp
  $onlyIf[$message[2]!=;Please give me the second arg!]
  $onlyIf[$message[1]!=;Please give me the first arg!]
  `
}