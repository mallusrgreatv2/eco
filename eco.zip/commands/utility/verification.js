module.exports = {
  name: "verification",
  code: `
  \`On\ or \`off\`?
  $onlyIf[$message[]!=off;{execute:verifyoff}]
  $onlyIf[$message[]!=on;{execute:verifyon}]
  $onlyPerms[manageserver;You do not have permission to do that!]
  `
}