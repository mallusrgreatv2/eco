module.exports = {
   name: "userinfo",
 aliases: ["user", "user-info", "whois", "ui"],
 code: `$author[$username[$mentioned[1;yes]]#$discriminator[$mentioned[1;yes]]]
 $description[_ _]
 $addField[Highest Role:;<@&$highestRole[$mentioned[1;yes]]>]

 $addField[Joined:;$creationDate[$mentioned[1;yes]];member]
 $addField[Created:;$creationDate[$mentioned[1;yes]];user]
 
 $addField[Device:;$platform[$mentioned[1;yes]]]

 $addField[Nickname:;$nickname[$mentioned[1;yes]]]
 $addField[ID:;\`$mentioned[1;yes]\`]
 $addField[Tag/Discriminator:;\`#$discriminator[$mentioned[1;yes]]\`]
 $addField[Name:;$username[$mentioned[1;yes]]]

 $thumbnail[$userAvatar[$mentioned[1;yes]]]
 `
}