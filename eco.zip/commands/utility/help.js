module.exports = {
  name: "help",
  code: `
  $title[help]
  $description[Be sure to use \`eco\` before every commands!]
  $addField[Moderation;\`kick\`,\`ban\`,\`purge\`,\`nickname\`,\`resetnick\`]
  $addField[fun;\`blur\`,\`captcha\`,\`clyde\`,\`feed\`,\`meme\`,\`riddle\`,\`rip\`,\`simp\`,\`trash\`,\`trump\`]
  $addField[Economy;\`balance\`,\`buy\`,\`daily\`,\`farm\`,\`fish\`,\`search\`,\`shop\`]
  $addField[Utilities;\`help\`,\`serverinfo\`]
  `
}