module.exports = {
  name: "verificationrole",
  aliases: ["vr"],
  code: `
  $title[Success]
  $description[Successfully set verification channel <@&$mentionedRoles[1]>]
  $addTimestamp
  $setServerVar[verifyrole;$mentionedRoles[1]]
  $onlyIf[$message[]!=;Please mention a role!]
  $onlyPerms[manageserver;You do not have permission to do that!]
  `
}