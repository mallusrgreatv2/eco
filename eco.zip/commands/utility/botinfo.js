module.exports = {
  name: "botinfo",
  code: `
  $title[Bot Info]
  $description[]
  $addField[Basics;name: $username[$client[id]]
  Version: $getVar[version]
  CPU: $cpu
  Client ID: $client[id]
  Activity: $activity[$client[id]]
  All members count: $allMembersCount
  Language: db-script(discordbot-script) + javascript(.js)
  Support server: {hyper:Click here:https://discord.gg/Z6Qg7yc}
  Authors/Developers: mallusrgreatv2#9999(700397009336533032)
  ]
  `
}