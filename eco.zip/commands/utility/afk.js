module.exports = {
  name: "afk",
  code: `
  $setNickname[$authorID;[AFK]$username[$authorID]]
  I set your AFK: $getVar[afkmsg;$authorID]
  $setVar[afkmsg;$message[];$authorID]
  $setVar[afk;on;$authorID]
  $onlyIf[$message[]!=;Please provide a reason]
  `
}