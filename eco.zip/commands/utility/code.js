module.exports = {
name: "code",
code: `
$giveRole[$authorID;$getServerVar[verifyrole]]
$title[Success]
$description[Successful verification. If you didn't get the role DM any server administrators]
$addTimestamp
$onlyIf[$getUserVar[verifycode]==$message[];The code you have given is invalid!]
$onlyIf[$message[]!=;Please give me the code or I can't verify you!]
$blackListRolesIDs[$getServerVar[verifyrole];:x::exclamation: You're already verified!]
`
}