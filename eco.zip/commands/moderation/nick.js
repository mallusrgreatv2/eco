module.exports = {
  name: "nickname",
  aliases: ["nick"],
  code: `
  Successfully set $username[$mentioned[1]]'s nickname to **$noMentionMessage[]**
  $setNickname[$mentioned[1];$noMentionMessage[]]
  $onlyPerms[managenicknames;You do not have permission to do that!]
  $onlyIf[$noMentionMessage[]!=;Please give me a nickname!]
  $onlyIf[$mentioned[1]!=;Please mention a user!]
  `
  
}