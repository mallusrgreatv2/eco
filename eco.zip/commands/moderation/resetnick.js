module.exports = {
  name: "resetnick",
  aliases: ["rn"],
  code: `
  Successfully set $username[$mentioned[1]]'s nickname to **$username[$mentioned[1]]**
  $setNickname[$mentioned[1];$username[$mentioned[1]]]
  $onlyIf[$mentioned[1]!=;Please mention a user!]
  $onlyPerms[managenicknames;You do not have permission to do that!]
  `
}