module.exports = {
  name: "purge",
 aliases: ["clear"],
 code: `$clear[$message[]]
 $description[Purged \`$message[1]\` messages.]
 $deletecommand[1ms]
 $deleteIn[2s]

 $onlyIf[$message[1]<=100;{description:You cannot remove more than 100 messages.}]


 $onlyIf[$isNumber[$message[1]]==true;{description: Your argument should be a number!}]
 $onlyIf[$message[]!=;{description:Please provide an amount.}]

 $onlyBotPerms[managemessages;I don't have permission to use this command! Do I have manage messages permission?]
 $onlyPerms[managemessages;:cross~3: You need more permissions to use this command!]

 `
}