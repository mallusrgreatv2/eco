module.exports = {
  name: "ban",
 code: `
 $ban[$mentioned[1];$noMentionMessage[]]
 $description[Banned **$username[$mentioned[1]]#$discriminator[$mentioned[1]]**. Reason: $noMentionMessage[]]
 
 $onlyIf[$noMentionMessage[]!=;Please provide a reason.]
 $onlyIf[$mentioned[1]!=;Please mention a user to ban]

 $onlyIf[$mentioned[1]!=$client[id];{description:I can't ban myself!}]
 $onlyIf[$ownerID!=$mentioned[1];{description:You cannot ban the server owner}]
 $onlyIf[$mentioned[1]!=$authorID;{description:I'm not sure you wanna ban yourself.}]

 $onlyBotPerms[ban;I don't have permission to use this command! Do I have ban permission?]
 $onlyPerms[ban;You need more permissions to use this command!]
 `
}