module.exports = {
  name: "feed",
  code: `
  $color[RANDOM]
  $title[$username[] Fed $username[$mentioned[1]]]
  $image[https://cdn.nekos.life/feed/feed_0$random[01;17].gif]
  $setVar[food;$sub[$getVar[food;$authorID];1];$authorID]
  $onlyIf[$mentioned[1]!=;Whom do you want to feed ?]
  $onlyIf[$getVar[food;$authorID]!=0;Oi you do not own a single food to feed others]

  `
}