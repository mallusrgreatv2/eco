module.exports = {
  name: "meme",
  code: `
  $title[$api[https://meme-api.herokuapp.com/gimme;title]]
 $description[
Posted on r/$api[https://meme-api.herokuapp.com/gimme;subreddit]]
$image[$api[https://meme-api.herokuapp.com/gimme;url]]
$footer[$api[https://meme-api.herokuapp.com/gimme;ups] 👍]
 
 `
}