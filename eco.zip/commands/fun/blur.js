module.exports = {
  name: "blur",
  code: `
  $addAttachment[https://useless-api.vierofernando.repl.co/blur?image=$userAvatar[$mentioned[1;yes]]]
  `
}