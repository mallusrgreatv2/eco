module.exports = {
  name: "say",
  code: `
  $title[Say]
  $description[$message[]]
  $footer[Said by $username[]]
  $addTimestamp
  `
}