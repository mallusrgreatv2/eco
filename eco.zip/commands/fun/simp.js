module.exports = {
  name: "simp",
 code: `$author[Simp rate]
 $description[$username[], you are **$random[0;100]**% simp!]
 $thumbnail[$userAvatar[]]
 $color[RANDOM]
 `
}