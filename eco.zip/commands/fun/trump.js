module.exports = {
  name: "trump",
  code: `
  $addAttachment[https://api.no-api-key.com/api/v2/trump?message=$replaceText[$message[]; ;%20]]
  `
}