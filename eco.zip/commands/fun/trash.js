module.exports = {
  name: "trash",
  code: `
  $title[$username[] Trashed $username[$mentioned[1]]]
$image[https://api.alexflipnote.dev/trash?face=$authorAvatar&trash=$userAvatar[$mentioned[1;yes]]]
$color[00ffdb]
$onlyIf[$mentioned[1]!=;Mention someone!]
$footer[ Among Us]
$addTimestamp
$botTyping
$suppressErrors[Please try again later.]
  `
}