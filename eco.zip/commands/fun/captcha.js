module.exports = {
  name: "captcha",
  code: `
  $addAttachment[https://api.alexflipnote.dev/captcha?text=$message[]]
  `
}