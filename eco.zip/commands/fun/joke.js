module.exports = {
   name: "joke",
 code: `
 $author[Joke:]
 $description[$api[https://some-random-api.ml/joke;joke]]
 $addTimestamp
 `
}