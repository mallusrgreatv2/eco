module.exports = {
  name: "clyde",
 code: `
  $addAttachment[https://ctk-api.herokuapp.com/clyde/$replaceText[$message[]; ;%20]]
 `
}