module.exports = {
  name: "riddle",
  code: `
  $title[Riddle]
  $addField[Answer;$api[https://no-api-key.com/api/v1/riddle;answer]]
  $addField[Question;$api[https://no-api-key.com/api/v1/riddle;question]]
  `
}