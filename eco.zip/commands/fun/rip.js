module.exports = {
  name: "rip",
  code: `
  $addAttachment[https://api.no-api-key.com/api/v2/rip?user_image=$replaceText[$userAvatar[$mentioned[1;yes]];.webp;.png]]
  `
}