module.exports = {
  name: "search",
  aliases: ["scout"],
  code: `
  $description[You are gonna search something. But where? type below! \`uber\, \`dumpster\`,\`hospital\`]
  $awaitMessages[toilet,uber,dumpster,hospital;$authorID;20s;toilet,uber,dumpster,hospital;You didn't reply!]
  $setVar[search;yes;$authorId]
  $cooldown[5m;Hey! You need to wait for {time} more!]
  $onlyIf[$getVar[search;$authorID]==no;]
  `
}