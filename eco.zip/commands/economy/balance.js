module.exports = {
  name: "balance",
  aliases: "bal",
  code: `
  $setVar[search;no;$authorID]
  $setVar[search;no;$authorID]
  $title[Your balance]
  $description[Your balance is $getVar[money;$authorID]]
  `
}