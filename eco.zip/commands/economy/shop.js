module.exports = {
  name: "shop",
  code: `
  $setVar[search;no;$authorID]
  $title[Shop]
  $description[Use \`eco buy <item name>\` to buy something from the shop]
  $addField[Fishing pole(fishpole);You have \`$getVar[fishpole;$authorID]\`, be able to use fish command]
  $addField[Hoe(hoe);You have $getVar[hoe;$authorID]. Access to farm command]
  $addField[food(food);You have $getVar[food;$authorID]. Access to feed command]
  `
}