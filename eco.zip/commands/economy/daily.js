module.exports = {
  name: "daily",
  code: `
  $setVar[search;no;$authorID]
  $cooldown[1d;{title:This is a daily bruh}{description:You need to wait for another {time} to claim another daily.}]
  $title[Your daily prize!]
  $description[Your daily prize is $random[2500;2600]]
  $setVar[money;$sum[$getVar[money;$authorID];$random[2500;2600]];$authorID]
  `
}