module.exports = {
  name: "buy",
  code: `
  $setVar[search;no;$authorID]
  $onlyIf[$message[]!=fishpole;{execute:fish}]
  $onlyIf[$message[]!=hoe;{execute:hoe}]
  $onlyIf[$message[]!=food;{execute:food}]
  `
}