module.exports = {
  name: "farm",
  code: `
  $setVar[search;no;$authorID]
  You farmed and got $random[1;100]$ from the owner
  $setVar[money;$sum[$getVar[money;$authorID];$random[1;100]]]
  $onlyIf[$getVar[hoe;$authorID]!=0;{title:Not enough resources}{description:You need a hoe to do this!}]
  `
}