module.exports = {
  name: "fish",
  code: `
  $setVar[search;no;$authorID]
  $cooldown[5m;{title:Cooldown}{description:Wait for another {time} to go for next fishing}]
  You fished and got $random[2;6] fishes. You sold them and got $random[1;200]$
  $setVar[money;$sum[$getVar[money;$authorID];$random[1;200]];$authorID]
  $onlyIf[$getVar[fishpole;$authorID]!=0;Oi you need a fishing pole]
  `
}