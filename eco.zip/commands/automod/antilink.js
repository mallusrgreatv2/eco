module.exports = {
  name: "antilink",
  code: `
  $onlyIf[$message[]!=on;{execute:antilinkon}]
  $onlyIf[$message[]!=off;{execute:antilinkoff}]
  `
}