module.exports = {
  name: "update",
  code: `
  Successfully updated bot to v$message[]
  $setVar[version;$message[]]
  $onlyForUsers[700397009336533032;This is an admin command!]
  `
}