const Dlang = require("discordbot-script");
const discordScript = require("discordbot-script");

const bot = new discordScript({
  token: "NzU1NDM2NTU2NTQ1Njg3NTcy.X2DRHg.Dn6Ffz6m3ohanb-Fh8CJ0PRA94Y",
  prefix: ["eco", "Eco"]
})

bot.Status({
  0:{
    description: "Bot reset",
    type: "WATCHING"
  }
}, 12000)

bot.Variables({
 snipemessage: "",
snipeuser: "",
fishpole: 0,
money: 0,
hoe: 0,
req: "50",
level: '0',
xp: "0",
food: "0",
search: "no",
afk: "off",
afkmsg: "",
version: "1.0.0",
antilink: "on",
verify: "off",
verifycode: "",
verifyrole: "",

})



bot.MessageEvent()
const fs = require('fs');
const {
    notDeepEqual
} = require("assert");
const {
    time
} = require("console");
const folders = fs.readdirSync("./commands/")

for (const files of folders) {
    const folder = fs.readdirSync(`./commands/${files}/`).filter(file => file.endsWith(".js"))

    for (const commands of folder) {
        const command = require(`./commands/${files}/${commands}`)
        bot.Command({
            name: command.name,
            aliases: command.aliases,
            description: command.description,
            api: command.api,
            code: command.code,
        })
    }
}

bot.MessageDeleteCommand({
 name: "$channelID[]",
 code: `$setChannelVar[snipemessage;$message[]]
$setChannelVar[snipeuser;$authorID]

$onlyIf[$message[]!=;]
`
});
bot.onMessageDelete();

bot.Command({
 name: "snipe",
 code: `$author[$username[$getChannelVar[snipeuser]]#$discriminator[$getChannelVar[snipeuser]]]
$description[$getChannelVar[snipemessage]]
$addTimestamp
$color[RANDOM]

$onlyIf[$getChannelVar[snipemessage]!=;{description:There's nothing to snipe!}]
`})
bot.Command({
name: "yt",
code: `
$addAttachment[https://some-random-api.ml/canvas/youtube-comment?avatar=$userAvatar[$authorID]&username=$username[$authorID]&comment=$message[]]
$onlyIf[$message[1]!=;{description:Not a valid comment!} {color:RANDOM}]
`
})
bot.ExecutableCommand({
  name: "fish",
  code: `
  You bought a fishing pole for 2,000$
  $setVar[money;$sub[$getVar[money;$authorID];2000];$authorID]
  $setVar[fishpole;$sum[$getVar[money;$authorID];1];$authorID]
  $onlyIf[$getVar[money;$authorID]>2000;{title:Not enough money}{description:You do not have 2,000 coins to buy a fishing pole!}]
  `
})
bot.ExecutableCommand({
  name: "hoe",
  code: `
  You bought a hoe for 1,000$
  $setVar[hoe;$sum[$getVar[hoe;$authorID];1];$authorID]
  $setVar[money;$sub[$getVar[money];1000];$authorID]
  $onlyIf[$getVar[money;$authorID]>1000;{title:Not enough money}{description:You need 1.000 coins to do this!}]
  `
})
bot.Command({
 name: "ai",
 code: `
<@$authorID> $api[https://some-random-api.ml/chatbot?message=$replaceText[$message[]; ;%20];response]
$onlyIf[$message[1]!=;{description:Ask me or say me something valid!} {color:RANDOM}]
 `
})
bot.Command({
  name: "magik",
  code: `
  $addAttachment[https://api.alexflipnote.dev/filter/magik?image=$userAvatar[$mentioned[1]]]
$onlyIf[$mentioned[1]!=;Mention someone!]
  `
})
bot.ExecutableCommand({
  name: "food",
  code: `
  You bought a food for 1,00$
  $setVar[food;$sum[$getVar[food;$authorID];1];$authorID]
  $setVar[money;$sub[$getVar[money];100];$authorID]
  $onlyIf[$getVar[money;$authorID]>1000;{title:Not enough money}{description:You need 100 coins to do this!}]
  `
})
bot.AwaitedCommand({
  name: "uber",
  code: `
  $cooldown[5m;]
  $setVar[search;no;$authorID]
  You searched Uber and got $random[10;200]$
  $setVar[money;$sum[$getVar[money;$authorID];$random[10;200]];$authorID]

  `
})
bot.AwaitedCommand({
  name: "toilet",
  code: `
  $cooldown[5m;]
  $setVar[search;no;$authorID]
  You searched toilet and got $random[10;200]$ somehow wtf
  $setVar[money;$sum[$getVar[money;$authorID];$random[10;200]];$authorID]
  `
})
bot.AwaitedCommand({
  name: "dumpster",
  code: `
  $cooldown[5m;]
  $setVar[search;no;$authorID]
  You searched dumpster and got $random[10;200]$ now Im really jealous of you ngl
  $setVar[money;$sum[$getVar[money;$authorID];$random[10;200]];$authorID]
  `
})
bot.SpaceCommand({
  name: "afk",
  code: `
  $username[$mentioned[1]] is AFK: $getVar[afkmsg;$mentioned[1]]
  $onlyIf[$getVar[afk;$mentioned[1]]==on;]
  $onlyIf[$getVar[afk;$authorID]==off;]
  `
})
bot.SpaceCommand({
  name: "aafk",
  code: `
  Welcome back, $username[]! I removed your AFK
  $setVar[afk;off;$authorID]
  $onlyIf[$getVar[afk;$authorID]==on;]
  `
})
bot.AwaitedCommand({
  name: "hospital",
  code: `
  You searched **Hospital** and found **$random[10;200]**$ Did you steal that from a sick person?
  $setVar[search;no;$authorID]
  $setVar[money;$sum[$getVar[money;$authorID];$random[10;200]];$authorID]
  `
})
bot.ExecutableCommand({
  name: "verifyoff",
  code: `
  Successfully set verification to off
  $setServerVar[verify;off]
  `
})
bot.ExecutableCommand({
  name: "verifyon",
  code: `
  Successfully set verification to on
  $setServerVar[verify;on]
  `
})
